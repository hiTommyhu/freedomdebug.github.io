## nrm

[`nrm`](https://www.npmjs.com/package/nrm)是一个 npm 源管理工具，本地安装以后，可以通过`nrm`十分方便的切换 npm 源地址。

```bash
npm install -g nrm
```

查看不同源

```bash
nrm ls
```

![image-20211128150858176](../../public/images/image-20211128150858176.png)

使用特定源

```bash
nrm use xxx
```

