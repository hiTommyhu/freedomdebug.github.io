---
title: 常用的 Nodejs 命令行开发工具
---

### [pnpm](https://pnpm.io/zh/installation)

### [commander](https://github.com/tj/commander.js/)

### [Inquirer](https://github.com/SBoudrias/Inquirer.js/)

### [chalk](https://github.com/chalk/chalk)

### [ora](https://github.com/sindresorhus/ora)

### [please-upgrade-node](https://github.com/typicode/please-upgrade-node)

### [shelljs](https://github.com/shelljs/shelljs)

### [ts-node](https://github.com/TypeStrong/ts-node)

### [node-glob](https://github.com/isaacs/node-glob)

### [nrm](https://github.com/Pana/nrm)

### cross-env
